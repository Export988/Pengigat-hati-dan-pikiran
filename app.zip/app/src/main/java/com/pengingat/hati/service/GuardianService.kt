package com.pengingat.hati.service

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import com.pengingat.hati.ui.BlockActivity
import com.pengingat.hati.util.Prefs

class GuardianService : AccessibilityService() {
    private lateinit var prefs: Prefs

    override fun onServiceConnected() {
        super.onServiceConnected()
        prefs = Prefs(this)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString() ?: return

        // 1) Block explicit packages completely
        if (prefs.getBlockedPackages().contains(pkg)) {
            showBlockScreen()
            return
        }

        // 2) For YouTube and browsers, scan text for 18+ keywords
        val isYouTube = pkg == "com.google.android.youtube"
        val isBrowser = pkg in listOf("com.android.chrome","org.mozilla.firefox","com.opera.browser","com.microsoft.emmx","com.brave.browser")

        if (isYouTube || isBrowser) {
            val texts = buildList {
                event.text?.forEach { add(it.toString()) }
                event.contentDescription?.let { add(it.toString()) }
            }.joinToString(" ").lowercase()

            if (texts.isNotBlank()) {
                val bad = prefs.getKeywords().any { k -> texts.contains(k.lowercase()) }
                if (bad) {
                    showBlockScreen()
                    return
                }
            }
        }
    }

    private fun showBlockScreen() {
        val i = Intent(this, BlockActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        }
        startActivity(i)
    }

    override fun onInterrupt() { /* no-op */ }
}