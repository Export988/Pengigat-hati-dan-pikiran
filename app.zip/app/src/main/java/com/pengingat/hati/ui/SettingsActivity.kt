package com.pengingat.hati.ui

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.pengingat.hati.R
import com.pengingat.hati.util.Prefs

class SettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        val prefs = Prefs(this)

        val etPass = findViewById<EditText>(R.id.etNewPassword)
        val etPackages = findViewById<EditText>(R.id.etBlockedPackages)
        val etKeywords = findViewById<EditText>(R.id.etKeywords)

        // load existing
        etPackages.setText(prefs.getBlockedPackages().joinToString(","))
        etKeywords.setText(prefs.getKeywords().joinToString(","))

        findViewById<Button>(R.id.btnSavePassword).setOnClickListener {
            val p = etPass.text.toString()
            if (p.length >= 4) {
                prefs.setPassword(p)
                Toast.makeText(this, "Kata sandi disimpan", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Minimal 4 karakter", Toast.LENGTH_SHORT).show()
            }
        }
        findViewById<Button>(R.id.btnSaveLists).setOnClickListener {
            prefs.setBlockedPackages(etPackages.text.toString().split(",").map { it.trim() }.filter { it.isNotEmpty() })
            prefs.setKeywords(etKeywords.text.toString().split(",").map { it.trim() }.filter { it.isNotEmpty() })
            Toast.makeText(this, "Daftar disimpan", Toast.LENGTH_SHORT).show()
        }
    }
}