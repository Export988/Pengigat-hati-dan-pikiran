package com.pengingat.hati.util

import android.content.Context

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("guardian_prefs", Context.MODE_PRIVATE)

    fun getPassword(): String = sp.getString("password", "2468") ?: "2468"
    fun setPassword(s: String) { sp.edit().putString("password", s).apply() }

    fun getBlockedPackages(): List<String> =
        sp.getString("blocked", "com.anime.play")!!.split(",").map { it.trim() }.filter { it.isNotEmpty() }
    fun setBlockedPackages(list: List<String>) {
        sp.edit().putString("blocked", list.joinToString(",")).apply()
    }

    fun getKeywords(): List<String> =
        sp.getString("keywords", "18+,porno,nsfw,xxx")!!.split(",").map { it.trim().lowercase() }.filter { it.isNotEmpty() }
    fun setKeywords(list: List<String>) {
        sp.edit().putString("keywords", list.joinToString(",")).apply()
    }
}