package com.pengingat.hati.ui

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.pengingat.hati.R
import com.pengingat.hati.util.Prefs

class BlockActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_block)

        val et = findViewById<EditText>(R.id.etPassword)
        val btn = findViewById<Button>(R.id.btnContinue)
        btn.setOnClickListener {
            val pass = Prefs(this).getPassword()
            if (et.text.toString() == pass) {
                finish() // allow returning to blocked app (if user knows password)
            } else {
                Toast.makeText(this, getString(R.string.wrong_password), Toast.LENGTH_SHORT).show()
            }
        }
    }
}